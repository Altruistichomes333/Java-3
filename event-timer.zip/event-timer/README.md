# event-timer
This app times an event and displays a message when on the deadline date
